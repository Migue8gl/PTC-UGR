#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  2 17:45:22 2023

@author: migue8gl
"""

import R1
import R2
import R3
import R4
import R5


def ejecutar():
    R1.ejecutar()
    R2.ejecutar()
    R3.ejecutar()
    R4.ejecutar()
    R5.ejecutar()


if __name__ == "__main__":
    ejecutar()
